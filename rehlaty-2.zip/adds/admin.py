from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(add_detail)
admin.site.register(a8sam1)